### Salt strees plot
data = pd.read_csv('salt_stress_table.csv') 



plot_erf4A_salt <- ggplot(data[data$treatment %in% 
                                 c("WT 0 mM NaCl", "Mutant 0 mM NaCl", 
                                   "WT 150 mM NaCl", "Mutant 150 mM NaCl"),], 
                          aes(x = days, y = germination, 
                              color = treatment)) +
  geom_line() +
  labs(title = "erf4A (At3g15210) - Salt stress", 
       x = "Time post-stratification (days)", 
       y = "Germination (%)") +
  theme_minimal()
print(plot_erf4A_salt)


### box plot (w/ no color)
library(ggplot2)

ggplot(diamonds) + 
geom_boxplot(aes(x = cut, y = price)) +
labs(
     title = "Price Distribution by Cut of Diamonds",
     x = "Cut",
     y = "Price"
) +
theme_minimal() +
theme(
      plot.title = element_text(size = 14, face = "bold"),
      axis.title.x = element_text(size = 12),
      axis.title.y = element_text(size = 12),
      axis.text = element_text(size = 10),
      legend.title = element_text(size = 12),
      legend.text = element_text(size = 10)
)

### box plot (w/ standard color)
library(ggplot2)

ggplot(diamonds) + 
  geom_boxplot(aes(x = cut, y = price, fill = cut)) +
  labs(
    title = "Price Distribution by Cut of Diamonds",
    x = "Cut",
    y = "Price"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    axis.text = element_text(size = 10),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 10)
  )


### box plot (w/ Set3 color)
library(ggplot2)

ggplot(diamonds) + 
  geom_boxplot(aes(x = cut, y = price, fill = cut)) +
  labs(
    title = "Price Distribution by Cut of Diamonds",
    x = "Cut",
    y = "Price"
  ) +
  theme_minimal() +
  scale_fill_brewer(palette = "Set3") +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    axis.text = element_text(size = 10),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 10)
  )


### bar plot
# Load necessary libraries
library(ggplot2)
library(readr)

# Load the data from the CSV file
data <- read_csv("salt_stress_table.csv")

# Plotting the bar plot
ggplot(data, aes(x = factor(days), y = germination, fill = treatment)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  labs(x = "Days", y = "Germination (%)", 
       title = "Germination Rate Over Time Under Different Conditions") +
  theme_minimal() +
  scale_fill_brewer(palette = "Set3") +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    axis.text = element_text(size = 10),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 10)
  )
